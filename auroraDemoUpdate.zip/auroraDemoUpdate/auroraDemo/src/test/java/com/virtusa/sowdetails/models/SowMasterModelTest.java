package com.virtusa.sowdetails.models;

import java.text.SimpleDateFormat;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class SowMasterModelTest {
	
	@InjectMocks
	SowMasterModel sowMasterModel;
	
	SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("dd-MM-yy");
	
	
	@Before
	public void setUp() {
		
		sowMasterModel = new SowMasterModel();
		sowMasterModel.setArea("Tech");
		sowMasterModel.setBusinessUnit("IM Shared Service - NAM");
		sowMasterModel.setCitiLegalEntity("Citigroup Technology Inc");
		sowMasterModel.setCitiProjectManager("Hari");
		sowMasterModel.setCitiProjectManagerEmailId("hari@citi.com");
		sowMasterModel.setCitiSowOwnerName("carolyn");
		sowMasterModel.setCitiSowOwnerEmailId("carolyn@citi.com");
		//sowMasterModel.setSignedEffectiveDate(simpleDateFormat1.format("20-02-20"));
		sowMasterModel.setContractName("Institutional client");
		sowMasterModel.setContractType("contract");
		sowMasterModel.setGeography("NAM");
		sowMasterModel.setSector("ICG");
		sowMasterModel.setServiceType("service");
		sowMasterModel.setSourceData("FG-SOW");
		sowMasterModel.setSowExecutingLocation("India");
		sowMasterModel.setSowId("T18077");
		sowMasterModel.setStatus("Active");
		sowMasterModel.setTenure(5);
		sowMasterModel.setVirtusaDDEmailId("dd@virtusa.com");
		sowMasterModel.setVirtusaDDName("DD");
		sowMasterModel.setVirtusaPDEmailId("pd@virtusa.com");
		sowMasterModel.setVirtusaPDName("PD");
		sowMasterModel.setVirtusaPMEmailId("pm@virtusa.com");
		sowMasterModel.setVirtusaPMName("PM");
		sowMasterModel.setVirtusaSegmentDeliveryHead("AMER BFS CITI TTS");	
	}
	@Test
	public void getAreaTest() {
		sowMasterModel.getArea();
	}
	@Test
	public void getBusinessUnitTest() {
		sowMasterModel.getBusinessUnit();
	}
	@Test
	public void getCitiLegalEntityTest() {
		sowMasterModel.getCitiLegalEntity();
	}
	@Test
	public void getCitiProjectManagerTest() {
		sowMasterModel.getCitiProjectManager();
	}
	@Test
	public void getCitiProjectManagerEmailIdTest() {
		sowMasterModel.getCitiProjectManagerEmailId();
	}
	@Test
	public void getCitiSowOwnerEmailIdTest() {
		sowMasterModel.getCitiSowOwnerEmailId();
	}
	@Test
	public void getCitiSowOwnerNameTest() {
		sowMasterModel.getCitiSowOwnerName();
	}
	@Test
	public void getCommencementDateTest() {
		sowMasterModel.getCommencementDate();
	}
	@Test
	public void getContractNameTest() {
		sowMasterModel.getContractName();
	}
	@Test
	public void getContractTypeTest() {
		sowMasterModel.getContractType();
	}
	@Test
	public void getExpiryDateTest() {
		sowMasterModel.getExpiryDate();
	}
	@Test
	public void getGeographyTest() {
		sowMasterModel.getGeography();
	}
	@Test
	public void getSectorTest() {
		sowMasterModel.getSector();
	}
	@Test
	public void getServiceTypeTest() {
		sowMasterModel.getServiceType();
	}
	@Test
	public void getSignedEffectiveDateTest() {
		sowMasterModel.getSignedEffectiveDate();
	}
	@Test
	public void getSourceDataTest() {
		sowMasterModel.getSourceData();
	}
	@Test
	public void getSowExecutingLocationTest() {
		sowMasterModel.getSowExecutingLocation();
	}
	@Test
	public void getSowIdTest() {
		sowMasterModel.getSowId();
	}
	@Test
	public void getStatusTest() {
		sowMasterModel.getStatus();
	}
	@Test
	public void getTenureTest() {
		sowMasterModel.getTenure();
	}
	@Test
	public void getVirtusaDDEmailIdTest() {
		sowMasterModel.getVirtusaDDEmailId();
	}
	@Test
	public void getVirtusaDDNameTest() {
		sowMasterModel.getVirtusaDDName();
	}
	@Test
	public void getVirtusaPDEmailIdTest() {
		sowMasterModel.getVirtusaPDEmailId();
	}@Test
	public void getVirtusaPDNameTest() {
		sowMasterModel.getVirtusaPDName();
	}
	@Test
	public void getVirtusaPMEmailIdTest() {
		sowMasterModel.getVirtusaPMEmailId();
	}
	@Test
	public void getVirtusaPMNameTest() {
		sowMasterModel.getVirtusaPMName();
	}
	@Test
	public void getVirtusaSegmentDeliveryHeadTest() {
		sowMasterModel.getVirtusaSegmentDeliveryHead();
	}
	
}
