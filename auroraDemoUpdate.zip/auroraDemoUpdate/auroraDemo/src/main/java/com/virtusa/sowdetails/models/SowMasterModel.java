package com.virtusa.sowdetails.models;

import java.util.Calendar;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/*
@Entity
@Table(name="Sample")
public class SowMasterModel {
	
	@Id
	private int id;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	private Calendar date;
	
	public Calendar getDate() {
		return date;
	}

	public void setDate(Calendar date) {
		this.date = date;
	}

	
}*/

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="SowMaster_details")
public class SowMasterModel {
	
	@Id
	@Column(name = "SOW_ID",columnDefinition="char(15)",nullable = false)
	private String sowId;
	
	@Column(name = "Contract_Name",columnDefinition="char(100)",nullable = false)
	private String contractName;
	
	@Column(name = "Signed_Effective_Date",nullable = false)
	private Date signedEffectiveDate;
	
	@Column(name = "Commencement_Date",nullable = false)
	private Date commencementDate;
	
	@Column(name = "Expiry_Date",nullable = false)
	private Date expiryDate;
	
	@Column(name = "Tenure",nullable = false)
	private int Tenure;
	
	@Column(name = "Contract_Type",columnDefinition="char(15)",nullable = false)
	private String contractType;
	
	@Column(name = "Service_Type",columnDefinition="char(20)",nullable = false)
	private String serviceType;
	
	@Column(name = "Source_Data",columnDefinition="char(50)",nullable = false)
	private String sourceData;
	
	@Column(name = "Status",columnDefinition="char(15)",nullable = false)
	private String status;
	
	@Column(name = "Citi_Legal_Entity",columnDefinition="char(50)",nullable = false)
	private String citiLegalEntity;
	
	@Column(name = "Geography",columnDefinition="char(20)",nullable = false)
	private String geography;
	
	@Column(name = "Sector",columnDefinition="char(20)",nullable = false)
	private String sector;
	
	@Column(name = "Sow_Executing_Location",columnDefinition="char(50)",nullable = false)
	private String sowExecutingLocation;
	
	@Column(name = "Area",columnDefinition="char(15)",nullable = false)
	private String area;
	
	@Column(name = "Business_Unit",columnDefinition="char(50)",nullable = false)
	private String businessUnit;
	
	@Column(name = "Citi_SOWOwner_Name",columnDefinition="char(30)",nullable = false)
	private String citiSowOwnerName;
	
	@Column(name = "Citi_SOWOwner_Email_Id",columnDefinition="char(50)",nullable = false)
	private String citiSowOwnerEmailId;
	
	@Column(name = "Citi_Project_Manager",columnDefinition="char(50)",nullable = false)
	private String citiProjectManager;
	
	@Column(name = "Citi_Project_Manager_EmailId",columnDefinition="char(50)",nullable = false)
	private String citiProjectManagerEmailId;
	
	@Column(name = "Virtusa_Segment_Delivery_Head",columnDefinition="char(50)",nullable = false)
	private String virtusaSegmentDeliveryHead;
	
	@Column(name = "Virtusa_DD_Name",columnDefinition="char(40)",nullable = false)
	private String virtusaDDName;
	
	@Column(name = "Virtusa_DD_EmailId",columnDefinition="char(50)",nullable = false)
	private String virtusaDDEmailId;
	
	@Column(name = "Virtusa_PD_Name",columnDefinition="char(40)",nullable = false)
	private String virtusaPDName;
	
	@Column(name = "Virtusa_PD_EmailId",columnDefinition="char(50)",nullable = false)
	private String virtusaPDEmailId;
	
	@Column(name = "Virtusa_PM_Name",columnDefinition="char(40)",nullable = false)
	private String virtusaPMName;
	
	@Column(name = "Virtusa_PM_EmailId",columnDefinition="char(50)",nullable = false)
	private String virtusaPMEmailId;

	

	public String getSowId() {
		return sowId;
	}
	public void setSowId(String sowId) {
		this.sowId = sowId;
	}
	public String getContractName() {
		return contractName;
	}
	public void setContractName(String contractName) {
		this.contractName = contractName;
	}
	
	public Date getSignedEffectiveDate() {
		return signedEffectiveDate;
	}
	public void setSignedEffectiveDate(Date signedEffectiveDate) {
		this.signedEffectiveDate = signedEffectiveDate;
	}
	public Date getCommencementDate() {
		return commencementDate;
	}
	public void setCommencementDate(Date commencementDate) {
		this.commencementDate = commencementDate;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	public int getTenure() {
		return Tenure;
	}
	public void setTenure(int tenure) {
		Tenure = tenure;
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getSourceData() {
		return sourceData;
	}
	public void setSourceData(String sourceData) {
		this.sourceData = sourceData;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCitiLegalEntity() {
		return citiLegalEntity;
	}
	public void setCitiLegalEntity(String citiLegalEntity) {
		this.citiLegalEntity = citiLegalEntity;
	}
	public String getGeography() {
		return geography;
	}
	public void setGeography(String geography) {
		this.geography = geography;
	}
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	public String getSowExecutingLocation() {
		return sowExecutingLocation;
	}
	public void setSowExecutingLocation(String sowExecutingLocation) {
		this.sowExecutingLocation = sowExecutingLocation;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	
	public String getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}
	public String getCitiSowOwnerName() {
		return citiSowOwnerName;
	}
	public void setCitiSowOwnerName(String citiSowOwnerName) {
		this.citiSowOwnerName = citiSowOwnerName;
	}
	public String getCitiSowOwnerEmailId() {
		return citiSowOwnerEmailId;
	}
	public void setCitiSowOwnerEmailId(String citiSowOwnerEmailId) {
		this.citiSowOwnerEmailId = citiSowOwnerEmailId;
	}
	public String getCitiProjectManager() {
		return citiProjectManager;
	}
	public void setCitiProjectManager(String citiProjectManager) {
		this.citiProjectManager = citiProjectManager;
	}
	public String getCitiProjectManagerEmailId() {
		return citiProjectManagerEmailId;
	}
	public void setCitiProjectManagerEmailId(String citiProjectManagerEmailId) {
		this.citiProjectManagerEmailId = citiProjectManagerEmailId;
	}
	public String getVirtusaSegmentDeliveryHead() {
		return virtusaSegmentDeliveryHead;
	}
	public void setVirtusaSegmentDeliveryHead(String virtusaSegmentDeliveryHead) {
		this.virtusaSegmentDeliveryHead = virtusaSegmentDeliveryHead;
	}
	public String getVirtusaDDName() {
		return virtusaDDName;
	}
	public void setVirtusaDDName(String virtusaDDName) {
		this.virtusaDDName = virtusaDDName;
	}
	public String getVirtusaDDEmailId() {
		return virtusaDDEmailId;
	}
	public void setVirtusaDDEmailId(String virtusaDDEmailId) {
		this.virtusaDDEmailId = virtusaDDEmailId;
	}
	public String getVirtusaPDName() {
		return virtusaPDName;
	}
	public void setVirtusaPDName(String virtusaPDName) {
		this.virtusaPDName = virtusaPDName;
	}
	public String getVirtusaPDEmailId() {
		return virtusaPDEmailId;
	}
	public void setVirtusaPDEmailId(String virtusaPDEmailId) {
		this.virtusaPDEmailId = virtusaPDEmailId;
	}
	public String getVirtusaPMName() {
		return virtusaPMName;
	}
	public void setVirtusaPMName(String virtusaPMName) {
		this.virtusaPMName = virtusaPMName;
	}
	public String getVirtusaPMEmailId() {
		return virtusaPMEmailId;
	}
	public void setVirtusaPMEmailId(String virtusaPMEmailId) {
		this.virtusaPMEmailId = virtusaPMEmailId;
	}
	
	
	
}
