package com.virtusa.sowdetails.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.sowdetails.models.SowMasterModel;
import com.virtusa.sowdetails.services.SowMasterService;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/citi-portal")
public class SowMasterController {

	@Autowired
	private SowMasterService sowMasterService;

	public void setSowMasterService(SowMasterService sowMasterService) {
		this.sowMasterService = sowMasterService;
	}

	// Adding the sowMaster details

	@PostMapping("/addDetails")
	public @ResponseBody SowMasterModel addSowMasterDetails(@RequestBody SowMasterModel model) {
		return this.sowMasterService.saveDetails(model);
	}

	// Adding List of sowMasterDetails
	@PostMapping("/addBulkDetails")
	public @ResponseBody List<SowMasterModel> addBulkSowMasterDetails(@RequestBody List<SowMasterModel> model) {
		return this.sowMasterService.saveBulkDetails(model);
	}
	// Viewing the sowmaster details

	@GetMapping("/getDetails")
	public @ResponseBody List<SowMasterModel> getSowMasterDetails() {

		return this.sowMasterService.getAllDetails();
	}

	// Viewing the sowmaster details based on sowid

	@GetMapping("/getDetailsByID/{sowId}")
	public @ResponseBody Optional<SowMasterModel> getSowMasterDetailsById(@PathVariable String sowId) {
		return this.sowMasterService.getDetails(sowId);
	}

	// Viewing the sowmaster details based on sector

	@GetMapping("/getDetailsBySector/{sector}")
	public @ResponseBody List<SowMasterModel> getSowMasterDetailsBySector(@PathVariable String sector) {
		System.out.println(sector);
		return this.sowMasterService.getDetailsBySector(sector);
	}

	// Viewing the sowmaster details based on status

	@GetMapping("/getDetailsByStatus/{status}")
	public @ResponseBody List<SowMasterModel> getSowMasterDetailsByStatus(@PathVariable String status) {
		System.out.println(status);
		return this.sowMasterService.getDetailsByStatus(status);
	}
	
	//update single record
	@PutMapping("/updateDetails")
	public @ResponseBody SowMasterModel updateSowMasterDetails(@RequestBody SowMasterModel model) {
		return this.sowMasterService.updateDetails(model);
	}

	
	
	// update Multiple sowMasterDetails
	@PutMapping("/updateBulkDetails")
	public void getMultipleRowDetails(@RequestBody List<SowMasterModel> sowMasterModel) {

		this.sowMasterService.updateMultipleRowDetails(sowMasterModel);

	}
}
