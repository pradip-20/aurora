package com.virtusa.projectmaster.services;
import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.projectmaster.annotations.PmField;
import com.virtusa.projectmaster.models.ProjectMasterModel;
import com.virtusa.projectmaster.repositories.ProjectMasterRepository;

@Service
public class ProjectuploadService {
	@Autowired
   ProjectMasterRepository projectRepo;
	public String phraseFile(String fileLocation)
			throws IllegalStateException, IOException {

		try {
			
			XSSFWorkbook workbook = new XSSFWorkbook(fileLocation);

			
			XSSFSheet sheet = workbook.getSheetAt(0);

			
			Map<Integer, String> headerMap = new HashMap<Integer, String>();
			Row headerRow = sheet.getRow(0);
			short minColumnIndex = headerRow.getFirstCellNum();
			short maxColumnIndex = headerRow.getLastCellNum();
			for (short i = minColumnIndex; i < maxColumnIndex; i++) {
				Cell cell = headerRow.getCell(i);
				headerMap.put((int) i, cell.getStringCellValue());
			}
			
			Iterator<Row> rowIterator = sheet.iterator();
			rowIterator.next();
			while (rowIterator.hasNext()) {
				
				ProjectMasterModel project = new ProjectMasterModel();
				Class<?> projectclass =project.getClass();
				
				Field[] fields = projectclass.getDeclaredFields();
				for (Field f : fields) {
					f.setAccessible(true);
				}
				Row row = rowIterator.next();

				
				Iterator<Cell> cellIterator = row.cellIterator();

				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();

					String fieldName = headerMap.get(cell.getColumnIndex()); // 
					try {
						System.out.println("*** Field : "+fieldName);
						Method projectMethod = getProjectMethod(fields, fieldName, project);
						if(projectMethod != null) {
							if (projectMethod.getParameterTypes()[0].equals(String.class)) {
								projectMethod.invoke(project, cell.getStringCellValue());
							} else if (projectMethod.getParameterTypes()[0].equals(Integer.class)) {
								Integer l = Integer.parseInt(cell.getStringCellValue());
								projectMethod.invoke(project, l);
							} else if (projectMethod.getParameterTypes()[0].equals(Long.class)) {
								Long l = Long.parseLong(cell.getStringCellValue());
								projectMethod.invoke(project, l);
														
							} else if (projectMethod.getParameterTypes()[0].equals(LocalDate.class)) {
								LocalDate d = cell.getDateCellValue().toInstant().atZone(ZoneId.systemDefault())
										.toLocalDate();
								projectMethod.invoke(project, d);
							}	else if(projectMethod.getParameterTypes()[0].equals(Boolean.class))		{
								Boolean b=Boolean.parseBoolean(cell.getStringCellValue());
								projectMethod.invoke(project, b);
							}
						}
					} catch (IntrospectionException ex) {
						System.out.println("**** "+ex.getLocalizedMessage());
					}
					System.out.println(project.toString());
					
				}
				project.setAuroraSegmentSeqfk(1);
				project.setAuroraServiceTypeVSeqfk(1);
				project.setAuroraDeliveryCenterSeqfk(1);
				project.setPricingConstructCodefk("pc1");
				project.setAuroraProgramSeqfk(1);
				project.setAuroraSOWSeqfk(1);
				project.setCreatedBy("pradipj");
				project.setCreatedDate(LocalDate.now());
				project.setModifiedBy("pradipj");
				project.setModifiedDate(LocalDate.now());
				project.setDeleted(false);
				projectRepo.save(project);
						
			}

		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
		
		return "Saved";
	}
	
	public Method getProjectMethod(Field[] fields, String fieldName, ProjectMasterModel project)
			throws IllegalArgumentException, IllegalAccessException, IntrospectionException {
		for (Field field : fields) {
			if (field.isAnnotationPresent(PmField.class) && fieldName.equals(getAnnotatedValue(field))) {
				String varName = (String) field.getName();
				PropertyDescriptor pd = new PropertyDescriptor(varName, project.getClass());
				Method setterMethod = pd.getWriteMethod();
				return setterMethod;
			}
		}
		return null;
	}

	private String getAnnotatedValue(Field field) {
		
		PmField projectAnnotation = field.getAnnotation(PmField.class);
		return (projectAnnotation != null) ? projectAnnotation.col() : "null";
	}


	
}