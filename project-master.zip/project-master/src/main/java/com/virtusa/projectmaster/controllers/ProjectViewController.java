package com.virtusa.projectmaster.controllers;

import java.util.List;
import java.util.Optional;

import javax.persistence.PreRemove;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.projectmaster.models.ProjectMasterModel;
import com.virtusa.projectmaster.services.ProjectMasterService;



@RestController
@RequestMapping("/api/citi-portal")
public class ProjectViewController {
	@Autowired
	ProjectMasterService projectService;

	public void setProjectService(ProjectMasterService projectService) {
		this.projectService = projectService;
	}

	@CrossOrigin("*")
	@GetMapping("/project-details")
	public @ResponseBody List<ProjectMasterModel> getProjectList() {
		return this.projectService.getAllDetails();
		
	}
	
	
	@CrossOrigin("*")
	@GetMapping("/project-details/{auroraProjectSeq}")
	public @ResponseBody Optional<ProjectMasterModel>GetProjectListBySeq(@PathVariable Integer auroraProjectSeq){
		return this.projectService.getAllBySeqId(auroraProjectSeq);
	}
	
	@CrossOrigin("*")
	@PostMapping("/project-details")
	public @ResponseBody ProjectMasterModel addProjectMasterModel(@RequestBody ProjectMasterModel projectMasterModel) {
		return this.projectService.saveDetail(projectMasterModel);
		
	}
	@CrossOrigin("*")
	@PutMapping("/project-details")
	public ProjectMasterModel updateProjectMasterModel(@RequestBody ProjectMasterModel model) {
		System.out.println(model.toString());
		return this.projectService.updateDetail(model);
	}
	
	//delete when entire model passed
	@PreRemove
	@DeleteMapping("/project-details")
	public void delProjectRecord(@RequestBody ProjectMasterModel pmodel) {
		 this.projectService.delRecord(pmodel);
	}
	
	//delete when id is passed
	@PreRemove
	@DeleteMapping("/project-details/{auroraProjectSeq}")
	public void deleteProjectModelById(@PathVariable int auroraProjectSeq) {
		this.projectService.deleteDetailsById(auroraProjectSeq);
		
	}
	


}
