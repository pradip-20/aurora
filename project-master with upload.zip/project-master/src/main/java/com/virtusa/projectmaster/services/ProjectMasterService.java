package com.virtusa.projectmaster.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.virtusa.projectmaster.annotations.PmField;
import com.virtusa.projectmaster.models.ProjectMasterModel;
import com.virtusa.projectmaster.repositories.ProjectMasterRepository;

@Service
public class ProjectMasterService {
	@Autowired
	private ProjectMasterRepository projectRepo;

	public void setProjectRepo(ProjectMasterRepository projectRepo) {
		this.projectRepo = projectRepo;
	}
	
	//getting projectMasterDetails
	public List<ProjectMasterModel> getAllDetails(){
		return projectRepo.findAll();
	}
	
	//getting project List by ProjectSeqId
	
	public Optional<ProjectMasterModel> getAllBySeqId(@PathVariable int auroraProjectSeq){
		return projectRepo.findById(auroraProjectSeq);
	}
	
	//adding project 
	
	public ProjectMasterModel saveDetail(@RequestBody ProjectMasterModel projectMasterModel) {
		projectMasterModel=projectRepo.save(projectMasterModel);
		
		return projectMasterModel;
	}
	
	//update project
	public ProjectMasterModel updateDetail(@RequestBody ProjectMasterModel projectMasterModel) {
		
		ProjectMasterModel pModel = projectRepo.findById(projectMasterModel.getAuroraProjectSeq()).orElse(null);
		pModel.setVelocityProjectCode(projectMasterModel.getVelocityProjectCode());
		pModel.setProjectName(projectMasterModel.getProjectName());
		pModel.setAuroraSegmentSeqfk(projectMasterModel.getAuroraSegmentSeqfk());
		pModel.setProjectStatus(projectMasterModel.getProjectStatus());
		pModel.setResourcesCurrentlyAllocated(projectMasterModel.getResourcesCurrentlyAllocated());
		pModel.setVelocityStartDate(projectMasterModel.getVelocityStartDate());
		pModel.setVelocityEndDate(projectMasterModel.getVelocityEndDate());
		pModel.setVirtusaSegmentDeliveryHead(projectMasterModel.getVirtusaSegmentDeliveryHead());
		pModel.setVirtusaDDName(projectMasterModel.getVirtusaDDName());
		pModel.setVirtusaDDEmailId(projectMasterModel.getVirtusaDDEmailId());
		pModel.setVirtusaPDName(projectMasterModel.getVirtusaPDName());
		pModel.setVirtusaPDEmailId(projectMasterModel.getVirtusaPDEmailId());
		pModel.setVirtusaPMName(projectMasterModel.getVirtusaPMName());
		pModel.setVirtusaPMEmailId(projectMasterModel.getVirtusaPMEmailId());
		pModel.setItCluster(projectMasterModel.getItCluster());
		pModel.setAuroraServiceTypeVSeqfk(projectMasterModel.getAuroraServiceTypeVSeqfk());
		pModel.setAuroraDeliveryCenterSeqfk(projectMasterModel.getAuroraDeliveryCenterSeqfk());
		pModel.setPricingConstructCodefk(projectMasterModel.getPricingConstructCodefk());
		pModel.setTotalHc(projectMasterModel.getTotalHc());
		pModel.setHcOn(projectMasterModel.getHcOn());
		pModel.setHcOff(projectMasterModel.getHcOff());
		pModel.setRecoveryTimeObjective(projectMasterModel.getRecoveryTimeObjective());
		pModel.setAuroraProgramSeqfk(projectMasterModel.getAuroraProgramSeqfk());
		pModel.setAuroraSOWSeqfk(projectMasterModel.getAuroraSOWSeqfk());
		pModel.setEngagementPlanApplicability(projectMasterModel.getEngagementPlanApplicability());
		pModel.setEngagementPlanExemptionReason(projectMasterModel.getEngagementPlanExemptionReason());
		pModel.setSlaApplicability(projectMasterModel.getSlaApplicability());
		pModel.setKpiApplicability(projectMasterModel.getKpiApplicability());
		pModel.setKeyPersonnelIncludingPM(projectMasterModel.getKeyPersonnelIncludingPM());
		pModel.setProjectLifeCycle(projectMasterModel.getProjectLifeCycle());
		pModel.setProjectApplicabilitySecureSDLC(projectMasterModel.getProjectApplicabilitySecureSDLC());
		pModel.setProjectMobileDevelopmentComponent(projectMasterModel.getProjectMobileDevelopmentComponent());
		pModel.setSelfAssessmentApplicability(projectMasterModel.getSelfAssessmentApplicability());
		pModel.setGovernanceReportApplicability(projectMasterModel.getGovernanceReportApplicability());
		pModel.setGovernanceReportFrequency(projectMasterModel.getGovernanceReportFrequency());
		pModel.setGdpr(projectMasterModel.getGdpr());
		pModel.setRemarks(projectMasterModel.getRemarks());
		pModel.setHighestConfidentiality(projectMasterModel.getHighestConfidentiality());
		pModel.setCreatedBy(projectMasterModel.getCreatedBy());
		pModel.setCreatedDate(projectMasterModel.getCreatedDate());
		pModel.setModifiedBy(projectMasterModel.getModifiedBy());
		pModel.setModifiedDate(projectMasterModel.getModifiedDate());	
		return projectRepo.save(pModel);
		
	}
	
	
	
	//delete record by projectseq
	public void deleteDetailsById(@PathVariable int auroraProjectSeq) {
		projectRepo.deleteById(auroraProjectSeq);
		System.out.print("Single record deleted");
		
	}
	
	//delete record when enitre record passed
	public void delRecord(@RequestBody ProjectMasterModel projectMasterModel)
	{
		int id=projectMasterModel.getAuroraProjectSeq();
		projectRepo.deleteById(id);
		System.out.print("deleted record by another method");
	}
	

}
