package com.virtusa.projectmaster.annotations;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.swing.LayoutFocusTraversalPolicy;
/**
 * Specifies the name of the column (header) from excel sheet being uploaded.
 */

@Target({FIELD})
@Retention(RUNTIME)
public @interface PmField {
	public String col() default "";

}
