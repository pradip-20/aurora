
package com.virtusa.projectmaster.services;
import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;


import com.virtusa.projectmaster.models.ProjectMasterModel;
import com.virtusa.projectmaster.repositories.ProjectMasterRepository;

@Service
public class ProjectuploadService {
	@Autowired
	private ProjectMasterRepository repository;
	
	ProjectMasterModel pModel = new ProjectMasterModel();
	
	
public String phraseFile(String file) throws IllegalStateException, IOException {
		
//public String phraseFile(String file) throws IllegalStateException, IOException {
		
		System.out.println("service layer");

		try {
			// Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(file);

			// Get first/desired sheet from the workbook
			XSSFSheet sheet = workbook.getSheetAt(0);

			// Iterate through each rows one by one
			Iterator<Row> rowIterator = sheet.iterator();
			rowIterator.next();
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();

				Iterator<Cell> cellIterator = row.cellIterator();
				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
				
					switch (cell.getColumnIndex()) {
							case 0:
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									pModel.setAuroraProjectSeq((int)cell.getNumericCellValue());
									break;
								} else {
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
								
							case 1:
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									pModel.setVelocityProjectCode((int)cell.getNumericCellValue());
									break;
								} else {
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 2:
								
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setProjectName(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
								
							case 3:
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									pModel.setAuroraSegmentSeqfk((int)cell.getNumericCellValue());
									break;
								} else {
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 4:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setProjectStatus(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 5:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setResourcesCurrentlyAllocated(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}

							case 6:
								try {

									if (cell.getCellTypeEnum() == CellType.STRING) {
								
										pModel.setVelocityStartDate(null);
										break;
									} else {
										System.out.print(cell.getDateCellValue() + "	| ");
									
										LocalDate d=cell.getDateCellValue().toInstant().atZone(ZoneId.systemDefault())
												.toLocalDate();
										
										pModel.setVelocityStartDate(d);
										break;
																													
									}

								} catch (Exception e) {
									System.out.println("Error in date entered");
								}
								
								
							case 7:
								try {

									if (cell.getCellTypeEnum() == CellType.STRING) {
								
										pModel.setVelocityEndDate(null);
										break;
									} else {
										System.out.print(cell.getDateCellValue() + "	| ");
									
										LocalDate d=cell.getDateCellValue().toInstant().atZone(ZoneId.systemDefault())
												.toLocalDate();
										
										pModel.setVelocityEndDate(d);
										break;
																													
									}

								} catch (Exception e) {
									System.out.println("Error in date entered");
								}
								
								
							case 8:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setVirtusaSegmentDeliveryHead(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}

							case 9:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setVirtusaDDName(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 10:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setVirtusaDDEmailId(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 11:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setVirtusaPDName(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}

							case 12:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setVirtusaPDEmailId(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
                        
							case 13:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setVirtusaPMName(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 14:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setVirtusaPMEmailId(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}


							case 15:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setItCluster(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}

								
							case 16:
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									pModel.setAuroraServiceTypeVSeqfk((int)cell.getNumericCellValue());
									break;
								} else {
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 17:
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									pModel.setAuroraDeliveryCenterSeqfk((int)cell.getNumericCellValue());
									break;
								} else {
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 18:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setPricingConstructCodefk(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 19:
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									pModel.setTotalHc((int)cell.getNumericCellValue());
									break;
								} else {
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 20:
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									pModel.setHcOn((int)cell.getNumericCellValue());
									break;
								} else {
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 21:
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									pModel.setHcOff((int)cell.getNumericCellValue());
									break;
								} else {
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 22:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setRecoveryTimeObjective(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
								
							case 23:
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									pModel.setAuroraProgramSeqfk((int)cell.getNumericCellValue());
									break;
								} else {
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 24:
								
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									pModel.setAuroraSOWSeqfk((int)cell.getNumericCellValue());
									break;
								} else {
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 25:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setEngagementPlanApplicability(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 26:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setEngagementPlanExemptionReason(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 27:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setSlaApplicability(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
												
							case 28:
								
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setKpiApplicability(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 29:
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									pModel.setKeyPersonnelIncludingPM((int)cell.getNumericCellValue());
									break;
								} else {
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
								
							case 30:
								
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setProjectLifeCycle(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 31:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setProjectApplicabilitySecureSDLC(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
								
							case 32:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setProjectMobileDevelopmentComponent(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 33:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setReleaseNotesApplicability(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 34:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setSelfAssessmentApplicability(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 35:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setGovernanceReportApplicability(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 36:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setGovernanceReportFrequency(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
								
							case 37:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setGdpr(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 38:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setRemarks(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
								
							case 39:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setHighestConfidentiality(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
								
							case 40:
								
								try {

									if (cell.getCellTypeEnum() == CellType.STRING) {
								
										pModel.setCreatedDate(null);
										break;
									} else {
										System.out.print(cell.getDateCellValue() + "	| ");
									
										LocalDate d=cell.getDateCellValue().toInstant().atZone(ZoneId.systemDefault())
												.toLocalDate();
										
										pModel.setCreatedDate(d);
										break;
																													
									}

								} catch (Exception e) {
									System.out.println("Error in date entered");
								}
								
								
							case 41:
								
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setCreatedBy(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
								
							case 42:
								try {

									if (cell.getCellTypeEnum() == CellType.STRING) {
								
										pModel.setModifiedDate(null);
										break;
									} else {
										System.out.print(cell.getDateCellValue() + "	| ");
									
										LocalDate d=cell.getDateCellValue().toInstant().atZone(ZoneId.systemDefault())
												.toLocalDate();
										
										pModel.setModifiedDate(d);
										break;
																													
									}

								} catch (Exception e) {
									System.out.println("Error in date entered");
								}
								
							case 43:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue()+ "	| ");
									pModel.setModifiedBy(cell.getStringCellValue());
									break;
								} else {

									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
																
								
								
		
					}

										
					
				}
				pModel.setDeleted(false);
				repository.save(pModel);
				System.out.println("");

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Saved Successfully";
	}


	
	
}