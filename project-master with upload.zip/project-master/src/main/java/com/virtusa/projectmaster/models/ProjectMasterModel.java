package com.virtusa.projectmaster.models;

import java.time.LocalDate;

import javax.persistence.Column;
import com.virtusa.projectmaster.annotations.PmField;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

@SQLDelete(sql =
"UPDATE Project_Master " +
        "SET deleted = true " +
        "WHERE Aurora_Project_Seq = ?")
@Where(clause = "deleted = false")
@Entity
@Table(name = "Project_Master")
public class ProjectMasterModel {
	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "Aurora_Project_Seq", nullable = false)
	//pradip jamdade  @PmField(col="Aurora_Project_Seq")
	private int auroraProjectSeq;
	
	@Column(name = "Velocity_ProjectCode", nullable = false)
	//@PmField(col="Velocity_ProjectCode")
	private int velocityProjectCode;
	
	@Column(name = "Project_Name", columnDefinition = "char(100)", nullable = false)
	//@PmField(col="Project_Name")
    private String projectName;
	
	@Column(name = "Aurora_Segment_Seq_fk", nullable = false)
	private int auroraSegmentSeqfk;
		
	@Column(name = "Project_Status", columnDefinition = "char(100)", nullable =false)
	//@PmField(col="Project_Status")
    private String projectStatus;

	@Column(name = "Resources_Currently_Allocated", columnDefinition = "char(1)", nullable = false)
	//@PmField(col="Resources_Currently_Allocated")
	private String resourcesCurrentlyAllocated;
	
	@Column(name = "Velocity_Start_Date", nullable = false)
	//@PmField(col="Velocity_Start_Date")
	private LocalDate velocityStartDate;
	
	@Column(name = "Velocity_End_Date", nullable = false)
	//@PmField(col ="Velocity_End_Date")
	private LocalDate velocityEndDate;
	
	@Column(name = "Virtusa_Segment_DeliveryHead", columnDefinition = "char(100)", nullable = false)
	//@PmField(col="Virtusa_Segment_DeliveryHead")
	private String virtusaSegmentDeliveryHead;
	
	@Column(name = "Virtusa_DD_Name", columnDefinition = "char(100)", nullable = false)
	//@PmField(col="Virtusa_DD_Name")
	private String virtusaDDName;
	
	
	@Column(name = "Virtusa_DD_EmailId", columnDefinition = "char(100)", nullable = true)
	//@PmField(col="Virtusa_DD_EmailId")
	private String virtusaDDEmailId;
	
	
	@Column(name = "Virtusa_PD_Name", columnDefinition = "char(100)", nullable = false)
	//@PmField(col="Virtusa_PD_Name")
	private String virtusaPDName;
	
	@Column(name = "Virtusa_PD_EmailId", columnDefinition = "char(100)", nullable = true)
	//@PmField(col="Virtusa_PD_EmailId")
	private String virtusaPDEmailId;
	
	@Column(name = "Virtusa_PM_Name", columnDefinition = "char(100)", nullable = false)
	//@PmField(col="Virtusa_PM_Name")
	private String virtusaPMName;
	
	@Column(name = "Virtusa_PM_EmailId", columnDefinition = "char(100)", nullable = true)
	//@PmField(col="Virtusa_PM_EmailId")
	private String virtusaPMEmailId;
	
	@Column(name = "IT_Cluster", columnDefinition = "char(5)", nullable = true)
	//@PmField(col="IT_Cluster")
	private String itCluster;
	
	
	@Column(name = "Aurora_ServiceType_V_Seq_fk", nullable = false)
	private int auroraServiceTypeVSeqfk;
	
	@Column(name = "Aurora_Delivery_Center_Seq_fk", nullable = false)
	private int auroraDeliveryCenterSeqfk;
	
	@Column(name = "Pricing_Construct_Code_fk", columnDefinition = "char(10)", nullable = false)
	private String pricingConstructCodefk;
	
	@Column(name = "Total_HC", nullable = false)
	//@PmField(col="Total_HC")
	private int totalHc;

	@Column(name = "HC_On", nullable = false)
	//@PmField(col="HC_On")
	private int hcOn;
	
	@Column(name = "HC_Off", nullable = false)
	//@PmField(col="HC_Off")
	private int hcOff;

	@Column(name = "Recovery_Time_Objective", columnDefinition = "char(45)", nullable = true)
	//@PmField(col="Recovery_Time_Objective")
	private String recoveryTimeObjective;
	
	@Column(name = "Aurora_Program_Seq_fk", nullable = false)
	private int auroraProgramSeqfk;
	
	@Column(name = "Aurora_SOW_Seq_fk", nullable = false)
	private int auroraSOWSeqfk;
	
	
	@Column(name = "Engagement_Plan_Applicability", columnDefinition = "char(30)", nullable = true)
	//@PmField(col="Engagement_Plan_Applicability")
	private String engagementPlanApplicability;
	
	@Column(name = "Engagement_Plan_Exemption_Reason", columnDefinition = "char(100)", nullable = true)
	//@PmField(col="Engagement_Plan_Exemption_Reason")
	private String engagementPlanExemptionReason;
	
	@Column(name = "SLA_Applicability", columnDefinition = "char(1)", nullable = true)
	//@PmField(col="SLA_Applicability")
	private String slaApplicability;
	
	@Column(name = "KPI_Applicability", columnDefinition = "char(1)", nullable = true)
	//@PmField(col="KPI_Applicability")
    private String kpiApplicability;
	
	@Column(name = "Key_Personnel_Including_PM", nullable = true)
	//@PmField(col="Key_Personnel_Including_PM")
	private int keyPersonnelIncludingPM;
	
	@Column(name = "Project_Life_Cycle", columnDefinition = "char(45)", nullable = true)
	//@PmField(col="Project_Life_Cycle")
	private String projectLifeCycle;
	
	@Column(name = "Project_Applicability_Secure_SDLC", columnDefinition = "char(1)", nullable = true)
	//@PmField(col="Project_Applicability_Secure_SDLC")
	private String projectApplicabilitySecureSDLC;
	
	@Column(name = "Project_Mobile_Development_Component", columnDefinition = "char(1)", nullable = true)
	//@PmField(col="Project_Mobile_Development_Component")
	private String projectMobileDevelopmentComponent;
		
	
	@Column(name = "Release_Notes_Applicability", columnDefinition = "char(45)", nullable = true)
	//@PmField(col="Release_Notes_Applicability")
	private String releaseNotesApplicability;
	
	@Column(name = "Self_Assessment_Applicability", columnDefinition = "char(45)", nullable = true)
	//@PmField(col="Self_Assessment_Applicability")
	private String selfAssessmentApplicability;
	
	
	@Column(name = "Governance_Report_Applicability", columnDefinition = "char(45)", nullable = true)
	//@PmField(col="Governance_Report_Applicability")
	private String governanceReportApplicability;
	
	
	@Column(name = "Governance_Report_Frequency", columnDefinition = "char(45)", nullable = true)
	//@PmField(col="Governance_Report_Frequency")
	private String governanceReportFrequency;
	
	
	@Column(name = "GDPR", columnDefinition = "char(45)", nullable = true)
	//@PmField(col="GDPR")
    private String gdpr;
	
	
	@Column(name = "Remarks", columnDefinition = "char(100)", nullable = true)
	//@PmField(col="Remarks")
	private String remarks;
	
	@Column(name = "Highest_Confidentiality", columnDefinition = "char(100)", nullable = true)
	//@PmField(col="Highest_Confidentiality")
	private String highestConfidentiality;
	
	
	@Column(name = "Created_Date", nullable = false)
	//@PmField(col="Created_Date")
	private LocalDate createdDate;
	
	@Column(name = "Created_By", columnDefinition = "char(100)", nullable = false)
	//@PmField(col="Created_By")
	private String createdBy;
	
	
	@Column(name = "Modified_Date", nullable = true)
	//@PmField(col="Modified_Date")
	private LocalDate modifiedDate;
	
	@Column(name = "Modified_By", columnDefinition = "char(100)", nullable = true)
//	@PmField(col="Modified_By")
	private String modifiedBy;
	
	@Column(name = "Deleted",nullable = true)
	private boolean deleted;
	public ProjectMasterModel() {
		
	}
	
	
	

	public ProjectMasterModel(int auroraProjectSeq, int velocityProjectCode, String projectName, String projectStatus,
			String resourcesCurrentlyAllocated, LocalDate velocityStartDate, LocalDate velocityEndDate,
			String virtusaSegmentDeliveryHead, String virtusaDDName, String virtusaDDEmailId, String virtusaPDName,
			String virtusaPDEmailId, String virtusaPMName, String virtusaPMEmailId, String itCluster, int totalHc,
			int hcOn, int hcOff, String recoveryTimeObjective, String engagementPlanApplicability,
			String engagementPlanExemptionReason, String slaApplicability, String kpiApplicability,
			int keyPersonnelIncludingPM, String projectLifeCycle, String projectApplicabilitySecureSDLC,
			String projectMobileDevelopmentComponent, String releaseNotesApplicability,
			String selfAssessmentApplicability, String governanceReportApplicability, String governanceReportFrequency,
			String gdpr, String remarks, String highestConfidentiality, LocalDate createdDate, String createdBy,
			LocalDate modifiedDate, String modifiedBy, boolean deleted) {
		super();
		this.auroraProjectSeq = auroraProjectSeq;
		this.velocityProjectCode = velocityProjectCode;
		this.projectName = projectName;
		this.projectStatus = projectStatus;
		this.resourcesCurrentlyAllocated = resourcesCurrentlyAllocated;
		this.velocityStartDate = velocityStartDate;
		this.velocityEndDate = velocityEndDate;
		this.virtusaSegmentDeliveryHead = virtusaSegmentDeliveryHead;
		this.virtusaDDName = virtusaDDName;
		this.virtusaDDEmailId = virtusaDDEmailId;
		this.virtusaPDName = virtusaPDName;
		this.virtusaPDEmailId = virtusaPDEmailId;
		this.virtusaPMName = virtusaPMName;
		this.virtusaPMEmailId = virtusaPMEmailId;
		this.itCluster = itCluster;
		this.totalHc = totalHc;
		this.hcOn = hcOn;
		this.hcOff = hcOff;
		this.recoveryTimeObjective = recoveryTimeObjective;
		this.engagementPlanApplicability = engagementPlanApplicability;
		this.engagementPlanExemptionReason = engagementPlanExemptionReason;
		this.slaApplicability = slaApplicability;
		this.kpiApplicability = kpiApplicability;
		this.keyPersonnelIncludingPM = keyPersonnelIncludingPM;
		this.projectLifeCycle = projectLifeCycle;
		this.projectApplicabilitySecureSDLC = projectApplicabilitySecureSDLC;
		this.projectMobileDevelopmentComponent = projectMobileDevelopmentComponent;
		this.releaseNotesApplicability = releaseNotesApplicability;
		this.selfAssessmentApplicability = selfAssessmentApplicability;
		this.governanceReportApplicability = governanceReportApplicability;
		this.governanceReportFrequency = governanceReportFrequency;
		this.gdpr = gdpr;
		this.remarks = remarks;
		this.highestConfidentiality = highestConfidentiality;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
		this.modifiedDate = modifiedDate;
		this.modifiedBy = modifiedBy;
		this.deleted = deleted;
	}




	public ProjectMasterModel(int auroraProjectSeq, int velocityProjectCode, String projectName, int auroraSegmentSeqfk,
			String projectStatus, String resourcesCurrentlyAllocated, LocalDate velocityStartDate,
			LocalDate velocityEndDate, String virtusaSegmentDeliveryHead, String virtusaDDName, String virtusaDDEmailId,
			String virtusaPDName, String virtusaPDEmailId, String virtusaPMName, String virtusaPMEmailId,
			String itCluster, int auroraServiceTypeVSeqfk, int auroraDeliveryCenterSeqfk, String pricingConstructCodefk,
			int totalHc, int hcOn, int hcOff, String recoveryTimeObjective, int auroraProgramSeqfk, int auroraSOWSeqfk,
			String engagementPlanApplicability, String engagementPlanExemptionReason, String slaApplicability,
			String kpiApplicability, int keyPersonnelIncludingPM, String projectLifeCycle,
			String projectApplicabilitySecureSDLC, String projectMobileDevelopmentComponent,
			String releaseNotesApplicability, String selfAssessmentApplicability, String governanceReportApplicability,
			String governanceReportFrequency, String gdpr, String remarks, String highestConfidentiality,
			LocalDate createdDate, String createdBy, LocalDate modifiedDate, String modifiedBy, boolean deleted) {
		super();
		this.auroraProjectSeq = auroraProjectSeq;
		this.velocityProjectCode = velocityProjectCode;
		this.projectName = projectName;
		this.auroraSegmentSeqfk = auroraSegmentSeqfk;
		this.projectStatus = projectStatus;
		this.resourcesCurrentlyAllocated = resourcesCurrentlyAllocated;
		this.velocityStartDate = velocityStartDate;
		this.velocityEndDate = velocityEndDate;
		this.virtusaSegmentDeliveryHead = virtusaSegmentDeliveryHead;
		this.virtusaDDName = virtusaDDName;
		this.virtusaDDEmailId = virtusaDDEmailId;
		this.virtusaPDName = virtusaPDName;
		this.virtusaPDEmailId = virtusaPDEmailId;
		this.virtusaPMName = virtusaPMName;
		this.virtusaPMEmailId = virtusaPMEmailId;
		this.itCluster = itCluster;
		this.auroraServiceTypeVSeqfk = auroraServiceTypeVSeqfk;
		this.auroraDeliveryCenterSeqfk = auroraDeliveryCenterSeqfk;
		this.pricingConstructCodefk = pricingConstructCodefk;
		this.totalHc = totalHc;
		this.hcOn = hcOn;
		this.hcOff = hcOff;
		this.recoveryTimeObjective = recoveryTimeObjective;
		this.auroraProgramSeqfk = auroraProgramSeqfk;
		this.auroraSOWSeqfk = auroraSOWSeqfk;
		this.engagementPlanApplicability = engagementPlanApplicability;
		this.engagementPlanExemptionReason = engagementPlanExemptionReason;
		this.slaApplicability = slaApplicability;
		this.kpiApplicability = kpiApplicability;
		this.keyPersonnelIncludingPM = keyPersonnelIncludingPM;
		this.projectLifeCycle = projectLifeCycle;
		this.projectApplicabilitySecureSDLC = projectApplicabilitySecureSDLC;
		this.projectMobileDevelopmentComponent = projectMobileDevelopmentComponent;
		this.releaseNotesApplicability = releaseNotesApplicability;
		this.selfAssessmentApplicability = selfAssessmentApplicability;
		this.governanceReportApplicability = governanceReportApplicability;
		this.governanceReportFrequency = governanceReportFrequency;
		this.gdpr = gdpr;
		this.remarks = remarks;
		this.highestConfidentiality = highestConfidentiality;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
		this.modifiedDate = modifiedDate;
		this.modifiedBy = modifiedBy;
		this.deleted = deleted;
	}

	public int getAuroraProjectSeq() {
		return auroraProjectSeq;
	}

	public void setAuroraProjectSeq(int auroraProjectSeq) {
		this.auroraProjectSeq = auroraProjectSeq;
	}

	public int getVelocityProjectCode() {
		return velocityProjectCode;
	}

	public void setVelocityProjectCode(int velocityProjectCode) {
		this.velocityProjectCode = velocityProjectCode;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public int getAuroraSegmentSeqfk() {
		return auroraSegmentSeqfk;
	}

	public void setAuroraSegmentSeqfk(int auroraSegmentSeqfk) {
		this.auroraSegmentSeqfk = auroraSegmentSeqfk;
	}

	public String getProjectStatus() {
		return projectStatus;
	}

	public void setProjectStatus(String projectStatus) {
		this.projectStatus = projectStatus;
	}

	public String getResourcesCurrentlyAllocated() {
		return resourcesCurrentlyAllocated;
	}

	public void setResourcesCurrentlyAllocated(String resourcesCurrentlyAllocated) {
		this.resourcesCurrentlyAllocated = resourcesCurrentlyAllocated;
	}

	public LocalDate getVelocityStartDate() {
		return velocityStartDate;
	}

	public void setVelocityStartDate(LocalDate velocityStartDate) {
		this.velocityStartDate = velocityStartDate;
	}

	public LocalDate getVelocityEndDate() {
		return velocityEndDate;
	}

	public void setVelocityEndDate(LocalDate velocityEndDate) {
		this.velocityEndDate = velocityEndDate;
	}

	public String getVirtusaSegmentDeliveryHead() {
		return virtusaSegmentDeliveryHead;
	}

	public void setVirtusaSegmentDeliveryHead(String virtusaSegmentDeliveryHead) {
		this.virtusaSegmentDeliveryHead = virtusaSegmentDeliveryHead;
	}

	public String getVirtusaDDName() {
		return virtusaDDName;
	}

	public void setVirtusaDDName(String virtusaDDName) {
		this.virtusaDDName = virtusaDDName;
	}

	public String getVirtusaDDEmailId() {
		return virtusaDDEmailId;
	}

	public void setVirtusaDDEmailId(String virtusaDDEmailId) {
		this.virtusaDDEmailId = virtusaDDEmailId;
	}

	public String getVirtusaPDName() {
		return virtusaPDName;
	}

	public void setVirtusaPDName(String virtusaPDName) {
		this.virtusaPDName = virtusaPDName;
	}

	public String getVirtusaPDEmailId() {
		return virtusaPDEmailId;
	}

	public void setVirtusaPDEmailId(String virtusaPDEmailId) {
		this.virtusaPDEmailId = virtusaPDEmailId;
	}

	public String getVirtusaPMName() {
		return virtusaPMName;
	}

	public void setVirtusaPMName(String virtusaPMName) {
		this.virtusaPMName = virtusaPMName;
	}

	public String getVirtusaPMEmailId() {
		return virtusaPMEmailId;
	}

	public void setVirtusaPMEmailId(String virtusaPMEmailId) {
		this.virtusaPMEmailId = virtusaPMEmailId;
	}

	public String getItCluster() {
		return itCluster;
	}

	public void setItCluster(String itCluster) {
		this.itCluster = itCluster;
	}

	public int getAuroraServiceTypeVSeqfk() {
		return auroraServiceTypeVSeqfk;
	}

	public void setAuroraServiceTypeVSeqfk(int auroraServiceTypeVSeqfk) {
		this.auroraServiceTypeVSeqfk = auroraServiceTypeVSeqfk;
	}

	public int getAuroraDeliveryCenterSeqfk() {
		return auroraDeliveryCenterSeqfk;
	}

	public void setAuroraDeliveryCenterSeqfk(int auroraDeliveryCenterSeqfk) {
		this.auroraDeliveryCenterSeqfk = auroraDeliveryCenterSeqfk;
	}

	public String getPricingConstructCodefk() {
		return pricingConstructCodefk;
	}

	public void setPricingConstructCodefk(String pricingConstructCodefk) {
		this.pricingConstructCodefk = pricingConstructCodefk;
	}

	public int getTotalHc() {
		return totalHc;
	}

	public void setTotalHc(int totalHc) {
		this.totalHc = totalHc;
	}

	public int getHcOn() {
		return hcOn;
	}

	public void setHcOn(int hcOn) {
		this.hcOn = hcOn;
	}

	public int getHcOff() {
		return hcOff;
	}

	public void setHcOff(int hcOff) {
		this.hcOff = hcOff;
	}

	public String getRecoveryTimeObjective() {
		return recoveryTimeObjective;
	}

	public void setRecoveryTimeObjective(String recoveryTimeObjective) {
		this.recoveryTimeObjective = recoveryTimeObjective;
	}

	public int getAuroraProgramSeqfk() {
		return auroraProgramSeqfk;
	}

	public void setAuroraProgramSeqfk(int auroraProgramSeqfk) {
		this.auroraProgramSeqfk = auroraProgramSeqfk;
	}

	public int getAuroraSOWSeqfk() {
		return auroraSOWSeqfk;
	}

	public void setAuroraSOWSeqfk(int auroraSOWSeqfk) {
		this.auroraSOWSeqfk = auroraSOWSeqfk;
	}

	public String getEngagementPlanApplicability() {
		return engagementPlanApplicability;
	}

	public void setEngagementPlanApplicability(String engagementPlanApplicability) {
		this.engagementPlanApplicability = engagementPlanApplicability;
	}

	public String getEngagementPlanExemptionReason() {
		return engagementPlanExemptionReason;
	}

	public void setEngagementPlanExemptionReason(String engagementPlanExemptionReason) {
		this.engagementPlanExemptionReason = engagementPlanExemptionReason;
	}

	public String getSlaApplicability() {
		return slaApplicability;
	}

	public void setSlaApplicability(String slaApplicability) {
		this.slaApplicability = slaApplicability;
	}

	public String getKpiApplicability() {
		return kpiApplicability;
	}

	public void setKpiApplicability(String kpiApplicability) {
		this.kpiApplicability = kpiApplicability;
	}

	public int getKeyPersonnelIncludingPM() {
		return keyPersonnelIncludingPM;
	}

	public void setKeyPersonnelIncludingPM(int keyPersonnelIncludingPM) {
		this.keyPersonnelIncludingPM = keyPersonnelIncludingPM;
	}

	public String getProjectLifeCycle() {
		return projectLifeCycle;
	}

	public void setProjectLifeCycle(String projectLifeCycle) {
		this.projectLifeCycle = projectLifeCycle;
	}

	public String getProjectApplicabilitySecureSDLC() {
		return projectApplicabilitySecureSDLC;
	}

	public void setProjectApplicabilitySecureSDLC(String projectApplicabilitySecureSDLC) {
		this.projectApplicabilitySecureSDLC = projectApplicabilitySecureSDLC;
	}

	public String getProjectMobileDevelopmentComponent() {
		return projectMobileDevelopmentComponent;
	}

	public void setProjectMobileDevelopmentComponent(String projectMobileDevelopmentComponent) {
		this.projectMobileDevelopmentComponent = projectMobileDevelopmentComponent;
	}

	public String getReleaseNotesApplicability() {
		return releaseNotesApplicability;
	}

	public void setReleaseNotesApplicability(String releaseNotesApplicability) {
		this.releaseNotesApplicability = releaseNotesApplicability;
	}

	public String getSelfAssessmentApplicability() {
		return selfAssessmentApplicability;
	}

	public void setSelfAssessmentApplicability(String selfAssessmentApplicability) {
		this.selfAssessmentApplicability = selfAssessmentApplicability;
	}

	public String getGovernanceReportApplicability() {
		return governanceReportApplicability;
	}

	public void setGovernanceReportApplicability(String governanceReportApplicability) {
		this.governanceReportApplicability = governanceReportApplicability;
	}

	public String getGovernanceReportFrequency() {
		return governanceReportFrequency;
	}

	public void setGovernanceReportFrequency(String governanceReportFrequency) {
		this.governanceReportFrequency = governanceReportFrequency;
	}

	public String getGdpr() {
		return gdpr;
	}

	public void setGdpr(String gdpr) {
		this.gdpr = gdpr;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getHighestConfidentiality() {
		return highestConfidentiality;
	}

	public void setHighestConfidentiality(String highestConfidentiality) {
		this.highestConfidentiality = highestConfidentiality;
	}

	public LocalDate getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDate getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(LocalDate modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}


	

		
	
}