package com.virtusa.projectmaster.controllers;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.zip.DataFormatException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.virtusa.projectmaster.services.ProjectuploadService;


@RestController
@RequestMapping("/api/citi-portal")
public class ProjectUploadController {
	@Autowired
	private ProjectuploadService projectUploadService;

	@PostMapping("/uploadFile")
	public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) throws IllegalStateException, IOException, DataFormatException  {
		InputStream in = file.getInputStream();
		File currDir = new File(".");
		String path = currDir.getAbsolutePath();
		String fileLocation = path.substring(0, path.length()-1)+file.getOriginalFilename();
		FileOutputStream fos = new FileOutputStream(fileLocation);
		int ch = 0;
		while((ch = in.read()) != -1) {
			fos.write(ch);
		}
		fos.flush();
		fos.close();
		String s = projectUploadService.phraseFile(fileLocation);
		if(s.equals("Saved Successfully")) {
			return new ResponseEntity<String>("File uploaded successfully", HttpStatus.OK);
		}else {
			throw new DataFormatException(s);
		}
	}


}
