package com.virtusa.projectmaster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectMasterApplicationTests {

	@Test
	void contextLoads() {
	}

}
